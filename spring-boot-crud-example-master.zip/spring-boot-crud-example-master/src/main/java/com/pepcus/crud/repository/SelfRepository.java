package com.pepcus.crud.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.pepcus.crud.entity.Self;

public interface SelfRepository extends JpaRepository<Self, Integer> {

}
